CLASS_COL = "class"
VALUE_COLS = [f"{i}" for i in range(0, 186)]
CLASSES = [f"{i}" for i in range(0, 4)]
